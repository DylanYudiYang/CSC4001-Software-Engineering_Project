from django.apps import AppConfig


class OwntracksConfig(AppConfig):
    name = 'owntracks'
